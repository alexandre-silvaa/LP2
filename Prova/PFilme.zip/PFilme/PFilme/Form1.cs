﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            lbxNotas.Items.Clear();

            string[,] notas = new string[40, 2];
            double[] notasF1 = new double[40];
            double[] notasF2 = new double[40];
            double nota;
            double mediaF1 = 0;
            double mediaF2 = 0;

            for (var i = 0; i < 40; i++)
            {
                for (var j = 0; j < 2; j++)
                {
                    notas[i, j] = Interaction.InputBox("Pessoa " + (i + 1) + " -  Digite a nota do filme" + (j + 1),
                    "Entrada de Notas");

                    if (double.TryParse(notas[i, j], out nota))
                    {
                        if (nota >= 0 && nota <= 10)
                        {
                            if(j == 0)
                            {
                                mediaF1 += nota;
                                notasF1[i] = nota;
                            }
                            else
                            {
                                mediaF2 += nota;
                                notasF2[i] = nota;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Insira uma nota maior ou igual a 0 e menor ou igual a 10");
                            j--;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Insira uma nota válida!");
                        j--;
                    }

         
                }

                lbxNotas.Items.Add("Pessoa " + (i + 1) + ": Nota Filme 1: " + notasF1[i].ToString("N2") + " Nota Filme 2: " + notasF2[i].ToString("N2"));
            }
            mediaF1 = mediaF1 / 40;
            mediaF2 = mediaF2 / 40;
            lbxNotas.Items.Add("--------------------------------------------");
            lbxNotas.Items.Add("Média Filme 1: " + mediaF1.ToString("N2"));
            lbxNotas.Items.Add("Média Filme 2: " + mediaF2.ToString("N2"));
        }
    }
}
